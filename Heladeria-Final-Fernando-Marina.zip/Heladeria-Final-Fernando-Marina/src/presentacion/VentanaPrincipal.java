
package presentacion;


import java.util.Arrays;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import model.Cucurucho;
import utils.Heladero;
import model.Vasito;
import model.Medio;
import model.Kilo;
import model.Cuarto;

/**
 *
 * @author fernandomarina
 */
public class VentanaPrincipal extends javax.swing.JFrame {
    
    float PrecioVasito=20f;
    float PrecioCucurucho=36f;
    float PrecioKilo=100f;
    float PrecioMedio=76;
    float PrecioCuarto=56;
    int cantidadGustos=0;
            
    public VentanaPrincipal() {
        initComponents();
        fillLists();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel4 = new javax.swing.JPanel();
        jSplitPane1 = new javax.swing.JSplitPane();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        RadioCucurucho = new javax.swing.JRadioButton();
        RadioVasito = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        RadioCuarto = new javax.swing.JRadioButton();
        RadioMedio = new javax.swing.JRadioButton();
        RadioKilo = new javax.swing.JRadioButton();
        jLabel5 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        ComboCantidadDeGustos = new javax.swing.JComboBox<>();
        CheckBañadoEnChocolate = new javax.swing.JCheckBox();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButtonAgregar = new javax.swing.JButton();
        jButtonQuitar = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaGustosDisponibles = new javax.swing.JList<>();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        listaGustosSeleccionados = new javax.swing.JList<>();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jButtonCancelar = new javax.swing.JButton();
        jButtonConfirmar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jButtonImprimir = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Tipo de helado", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 3, 14))); // NOI18N
        jPanel1.setFont(new java.awt.Font("Lucida Grande", 0, 12)); // NOI18N

        buttonGroup2.add(RadioCucurucho);
        RadioCucurucho.setText("Cucurucho");
        RadioCucurucho.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RadioCucuruchoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                RadioCucuruchoMouseEntered(evt);
            }
        });
        RadioCucurucho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioCucuruchoActionPerformed(evt);
            }
        });

        buttonGroup2.add(RadioVasito);
        RadioVasito.setText("Vasito");
        RadioVasito.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RadioVasitoMouseClicked(evt);
            }
        });

        jLabel1.setText("Ingrese el tipo de helado :");

        buttonGroup2.add(RadioCuarto);
        RadioCuarto.setText("1/4 Kilo");
        RadioCuarto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RadioCuartoMouseClicked(evt);
            }
        });
        RadioCuarto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioCuartoActionPerformed(evt);
            }
        });

        buttonGroup2.add(RadioMedio);
        RadioMedio.setText("1/2 Kilo");
        RadioMedio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RadioMedioMouseClicked(evt);
            }
        });

        buttonGroup2.add(RadioKilo);
        RadioKilo.setText("1 Kilo");
        RadioKilo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RadioKiloMouseClicked(evt);
            }
        });
        RadioKilo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RadioKiloActionPerformed(evt);
            }
        });

        jLabel5.setText("Pote :");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(RadioCucurucho)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 48, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(RadioKilo)
                    .addComponent(RadioMedio)
                    .addComponent(RadioCuarto))
                .addGap(70, 70, 70))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel1))
                    .addComponent(RadioVasito))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioCucurucho)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioVasito)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(RadioCuarto))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(RadioMedio)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(RadioKilo)
                .addContainerGap(40, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Cantidad de Gustos", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 3, 14))); // NOI18N

        ComboCantidadDeGustos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        ComboCantidadDeGustos.setName(""); // NOI18N
        ComboCantidadDeGustos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboCantidadDeGustosActionPerformed(evt);
            }
        });

        CheckBañadoEnChocolate.setText("Bañado en chocolate");
        CheckBañadoEnChocolate.setEnabled(false);
        CheckBañadoEnChocolate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CheckBañadoEnChocolateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(CheckBañadoEnChocolate)
                .addGap(109, 109, 109))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(ComboCantidadDeGustos, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ComboCantidadDeGustos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(CheckBañadoEnChocolate)
                .addGap(52, 52, 52))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 3, 18)); // NOI18N
        jLabel2.setText("Seleccion de Gustos");

        jButtonAgregar.setText("Agregar");
        jButtonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAgregarActionPerformed(evt);
            }
        });

        jButtonQuitar.setText("Quitar");
        jButtonQuitar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonQuitarActionPerformed(evt);
            }
        });

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Gustos disponibles"));

        listaGustosDisponibles.setEnabled(false);
        listaGustosDisponibles.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                listaGustosDisponiblesPropertyChange(evt);
            }
        });
        jScrollPane1.setViewportView(listaGustosDisponibles);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Gustos Seleccionados "));

        jScrollPane2.setViewportView(listaGustosSeleccionados);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(jButtonAgregar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButtonQuitar)
                .addGap(103, 103, 103))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(171, 171, 171)
                .addComponent(jLabel2)
                .addContainerGap(244, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonAgregar)
                    .addComponent(jButtonQuitar))
                .addContainerGap())
        );

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel3.setText("TOTAL A PAGAR");

        jButtonCancelar.setText("Cancelar");
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });

        jButtonConfirmar.setText("Confirmar");
        jButtonConfirmar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonConfirmarMouseClicked(evt);
            }
        });
        jButtonConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonConfirmarActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel4.setText("Heladeria");

        jButtonImprimir.setText("Imprimir");
        jButtonImprimir.setEnabled(false);
        jButtonImprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonImprimirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonImprimir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonCancelar)
                        .addGap(12, 12, 12)
                        .addComponent(jButtonConfirmar)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(225, 225, 225)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonCancelar)
                    .addComponent(jButtonConfirmar)
                    .addComponent(jButtonImprimir))
                .addGap(14, 14, 14))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

     private void fillLists() {
        DefaultListModel<String> listModelDisponibles = new DefaultListModel<>();
        listaGustosDisponibles.setModel(listModelDisponibles);
        DefaultListModel<String> listModelSeleccionados = new DefaultListModel<>();
        listaGustosSeleccionados.setModel(listModelSeleccionados);
        
        List<String> listaGustos = Arrays.asList("Frutilla", "Vainilla", "Limon", "Chocolate");
        
         for (String gusto : listaGustos) {
             listModelDisponibles.addElement(gusto);
         }
     }
    
    
    private void RadioCucuruchoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioCucuruchoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioCucuruchoActionPerformed
  
          
    private void RadioKiloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioKiloActionPerformed
        // TODO add your handling code here:
          
    }//GEN-LAST:event_RadioKiloActionPerformed

    private void ComboCantidadDeGustosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboCantidadDeGustosActionPerformed
    
        
         if(ComboCantidadDeGustos.getSelectedItem()!="Cantidad de gustos sin definir"){
                listaGustosDisponibles.setEnabled(true);
                listaGustosSeleccionados.setEnabled(true);
        } 
         else {
                listaGustosDisponibles.setEnabled(false);
                listaGustosSeleccionados.setEnabled(false);
         }
    }//GEN-LAST:event_ComboCantidadDeGustosActionPerformed

    private void jButtonConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonConfirmarActionPerformed
        Heladero heladero = new Heladero();
       
        DefaultListModel<String>  listModelSeleccionados = (DefaultListModel<String>)listaGustosSeleccionados.getModel();
            if(buttonGroup2.getSelection()==null){
                JOptionPane.showMessageDialog(this, "Disculpe pero debe seleccionar un tipo de helado", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if(ComboCantidadDeGustos.getSelectedItem()=="Cantidad de gustos sin definir"){
               JOptionPane.showMessageDialog(this, "Disculpe pero debe seleccionar la cantidad de gustos", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if(listModelSeleccionados.isEmpty()){
                JOptionPane.showMessageDialog(this, "Disculpe pero debe seleccionar al menos un gusto para realizar el pedido", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if(RadioCucurucho.isSelected()){
            jTextField1.setText(heladero.describirPrecio(new Cucurucho(PrecioCucurucho,true)));
            jButtonImprimir.setEnabled(true);
            }
            else if(RadioVasito.isSelected()){
            jTextField1.setText(heladero.describirPrecio(new Vasito(PrecioVasito)));
            jButtonImprimir.setEnabled(true);
            }
            else if(RadioKilo.isSelected()){
            jTextField1.setText(heladero.describirPrecio(new Kilo(PrecioKilo)));
            jButtonImprimir.setEnabled(true);
            }
            else if(RadioMedio.isSelected()){
            jTextField1.setText(heladero.describirPrecio(new Medio(PrecioMedio)));
            jButtonImprimir.setEnabled(true);
            }
            else if(RadioCuarto.isSelected()){
            jTextField1.setText(heladero.describirPrecio(new Cuarto(PrecioCuarto)));
            jButtonImprimir.setEnabled(true);
            }    
    }//GEN-LAST:event_jButtonConfirmarActionPerformed

    private void CheckBañadoEnChocolateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CheckBañadoEnChocolateActionPerformed
      
    }//GEN-LAST:event_CheckBañadoEnChocolateActionPerformed

    private void RadioCucuruchoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RadioCucuruchoMouseClicked
    
        if(RadioCucurucho.isSelected()){
                CheckBañadoEnChocolate.setEnabled(true);
                ComboCantidadDeGustos.setEnabled(true);
                ComboCantidadDeGustos.removeAllItems();
                ComboCantidadDeGustos.addItem("Cantidad de gustos sin definir");
                ComboCantidadDeGustos.addItem("1");
                ComboCantidadDeGustos.addItem("2"); 
        }
    }//GEN-LAST:event_RadioCucuruchoMouseClicked

    private void RadioCucuruchoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RadioCucuruchoMouseEntered
        // TODO add your handling code here: 
    }//GEN-LAST:event_RadioCucuruchoMouseEntered

    private void RadioVasitoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RadioVasitoMouseClicked
    
        if(RadioVasito.isSelected()){
            CheckBañadoEnChocolate.setEnabled(false);
            ComboCantidadDeGustos.setEnabled(true);
            ComboCantidadDeGustos.removeAllItems();
            ComboCantidadDeGustos.addItem("Cantidad de gustos sin definir");
            ComboCantidadDeGustos.addItem("1");
            ComboCantidadDeGustos.addItem("2");
        }
    }//GEN-LAST:event_RadioVasitoMouseClicked

    private void RadioCuartoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RadioCuartoMouseClicked
       
        if(RadioCuarto.isSelected()){
            CheckBañadoEnChocolate.setEnabled(false);  
            ComboCantidadDeGustos.setEnabled(true);
            ComboCantidadDeGustos.removeAllItems();
            ComboCantidadDeGustos.addItem("Cantidad de gustos sin definir");
            ComboCantidadDeGustos.addItem("1");
            ComboCantidadDeGustos.addItem("2");      
        }
    }//GEN-LAST:event_RadioCuartoMouseClicked

    private void RadioMedioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RadioMedioMouseClicked

        if(RadioMedio.isSelected()){
            CheckBañadoEnChocolate.setEnabled(false);
            ComboCantidadDeGustos.setEnabled(true);
            ComboCantidadDeGustos.removeAllItems();
            ComboCantidadDeGustos.addItem("Cantidad de gustos sin definir");
            ComboCantidadDeGustos.addItem("1");
            ComboCantidadDeGustos.addItem("2");
            ComboCantidadDeGustos.addItem("3");
        }
    }//GEN-LAST:event_RadioMedioMouseClicked

    private void RadioKiloMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RadioKiloMouseClicked
        
        if(RadioKilo.isSelected()){
            CheckBañadoEnChocolate.setEnabled(false);
            ComboCantidadDeGustos.setEnabled(true);
            ComboCantidadDeGustos.removeAllItems();
            ComboCantidadDeGustos.addItem("Cantidad de gustos sin definir");
            ComboCantidadDeGustos.addItem("1");
            ComboCantidadDeGustos.addItem("2");
            ComboCantidadDeGustos.addItem("3");
            ComboCantidadDeGustos.addItem("4");
        }
    }//GEN-LAST:event_RadioKiloMouseClicked

    private void jButtonConfirmarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonConfirmarMouseClicked
   
    }//GEN-LAST:event_jButtonConfirmarMouseClicked

    private void jButtonImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonImprimirActionPerformed
        Heladero heladero = new Heladero();
        
        if(RadioCucurucho.isSelected()){
            if(CheckBañadoEnChocolate.isSelected()){
                JOptionPane.showMessageDialog(this, "Pedido Confirmado. Su Helado Cucurucho tiene  "+cantidadGustos +"  gusto/s"+ listaGustosSeleccionados.getModel()+ heladero.describirHelado(new Cucurucho(PrecioCucurucho,true)), "Información", JOptionPane.INFORMATION_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(this, "Pedido Confirmado. Su Helado Cucurucho tiene  "+cantidadGustos +"  gusto/s"+ listaGustosSeleccionados.getModel()+ heladero.describirHelado(new Cucurucho(PrecioCucurucho,false)), "Información", JOptionPane.INFORMATION_MESSAGE);
                }
            }   
        else if(RadioVasito.isSelected()){
            JOptionPane.showMessageDialog(this, "Pedido Confirmado. Su Helado de Vasito tiene  "+ cantidadGustos +"  gusto/s"+ listaGustosSeleccionados.getModel()+ heladero.describirHelado(new Vasito(PrecioVasito)), "Información", JOptionPane.INFORMATION_MESSAGE);
        }
        else if(RadioMedio.isSelected()){
            JOptionPane.showMessageDialog(this, "Pedido Confirmado. Su medio kilo de Helado tiene  "+ cantidadGustos +"  gusto/s"+ listaGustosSeleccionados.getModel()+ heladero.describirHelado(new Medio(PrecioMedio)), "Información", JOptionPane.INFORMATION_MESSAGE);
        }
        else if(RadioKilo.isSelected()){
            JOptionPane.showMessageDialog(this, "Pedido Confirmado. Su kilo de Helado tiene  "+cantidadGustos +"  gusto/s"+ listaGustosSeleccionados.getModel()+ heladero.describirHelado(new Kilo(PrecioKilo)), "Información", JOptionPane.INFORMATION_MESSAGE);
        }
        else if(RadioCuarto.isSelected()){
            JOptionPane.showMessageDialog(this, "Pedido Confirmado. Su cuarto de Helado tiene  "+cantidadGustos +"  gusto/s"+ listaGustosSeleccionados.getModel()+ heladero.describirHelado(new Cuarto(PrecioCuarto)), "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_jButtonImprimirActionPerformed

    
    private void jButtonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAgregarActionPerformed
            String ComCantDeGustos = (String) ComboCantidadDeGustos.getSelectedItem(); 
            String GustosDisponibles = listaGustosDisponibles.getSelectedValue();
            String GustosSeleccionados = listaGustosSeleccionados.getSelectedValue();
         int CantidadGustosSeleccionados = listaGustosSeleccionados.getModel().getSize();
         System.out.println("getCC " + CantidadGustosSeleccionados);
         System.out.println("combo box"+cantidadGustos);
         System.out.println(ComCantDeGustos);
          
        if(GustosDisponibles == null){
                   JOptionPane.showMessageDialog(this, "Primero seleccione un ingrediente para agregar", "Error", JOptionPane.ERROR_MESSAGE);
        }
        else if (ComCantDeGustos.equals("1")){
             cantidadGustos=1;
                 DefaultListModel<String>  listModelSeleccionados = (DefaultListModel<String>)listaGustosSeleccionados.getModel();
                 DefaultListModel<String>  listModelDisponibles = (DefaultListModel<String>)listaGustosDisponibles.getModel();
                 listModelSeleccionados.addElement(GustosDisponibles);
                 System.out.print(listModelSeleccionados);
                 listModelDisponibles.removeElement(GustosDisponibles); 
         }
         else if (ComCantDeGustos.equals("2")){
             cantidadGustos=2;
                 DefaultListModel<String>  listModelSeleccionados = (DefaultListModel<String>)listaGustosSeleccionados.getModel();
                 DefaultListModel<String>  listModelDisponibles = (DefaultListModel<String>)listaGustosDisponibles.getModel();
                 listModelSeleccionados.addElement(GustosDisponibles);
                 listModelDisponibles.removeElement(GustosDisponibles); 
         }
         else if (ComCantDeGustos.equals("3")){
             cantidadGustos=3;
                 DefaultListModel<String>  listModelSeleccionados = (DefaultListModel<String>)listaGustosSeleccionados.getModel();
                 DefaultListModel<String>  listModelDisponibles = (DefaultListModel<String>)listaGustosDisponibles.getModel();
                 listModelSeleccionados.addElement(GustosDisponibles);
                 listModelDisponibles.removeElement(GustosDisponibles); 
         }
         else if (ComCantDeGustos.equals("4")){
             cantidadGustos=4;
                 DefaultListModel<String>  listModelSeleccionados = (DefaultListModel<String>)listaGustosSeleccionados.getModel();
                 DefaultListModel<String>  listModelDisponibles = (DefaultListModel<String>)listaGustosDisponibles.getModel();
                 listModelSeleccionados.addElement(GustosDisponibles);
                 listModelDisponibles.removeElement(GustosDisponibles); 
         }
       else if(cantidadGustos == CantidadGustosSeleccionados){
            JOptionPane.showMessageDialog(this, "Disculpe selecciono"+cantidadGustos+"Gustos", "Error", JOptionPane.ERROR_MESSAGE);
            jButtonAgregar.setEnabled(false);  
       }
        
       else {
                jButtonAgregar.setEnabled(true);
                 DefaultListModel<String>  listModelSeleccionados = (DefaultListModel<String>)listaGustosSeleccionados.getModel();
                 DefaultListModel<String>  listModelDisponibles = (DefaultListModel<String>)listaGustosDisponibles.getModel();

                 listModelSeleccionados.addElement(GustosDisponibles);
                 listModelDisponibles.removeElement(GustosDisponibles);               
                 System.out.println("getCC22 " + listModelSeleccionados.getSize());
         
        } 
          
    }//GEN-LAST:event_jButtonAgregarActionPerformed

    private void jButtonQuitarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonQuitarActionPerformed
        
            String GustosSeleccionados = listaGustosSeleccionados.getSelectedValue();
            
            DefaultListModel<String>  listModelSeleccionados = (DefaultListModel<String>)listaGustosSeleccionados.getModel();
            DefaultListModel<String>  listModelDisponibles = (DefaultListModel<String>)listaGustosDisponibles.getModel();
            
            listModelSeleccionados.removeElement(GustosSeleccionados);
            listModelDisponibles.addElement(GustosSeleccionados);

        
    }//GEN-LAST:event_jButtonQuitarActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        int respuesta = JOptionPane.showConfirmDialog(null, "¿Esta seguro de que quiere cancelar?", "Alerta!", JOptionPane.YES_NO_OPTION);
        
        if(respuesta == JOptionPane.YES_OPTION){
            
            buttonGroup2.clearSelection();
            ComboCantidadDeGustos.setEnabled(false);
            ComboCantidadDeGustos.removeAllItems();
            CheckBañadoEnChocolate.setEnabled(false);
            jTextField1.setText("");
            
            DefaultListModel<String>  listModelSeleccionados = (DefaultListModel<String>)listaGustosSeleccionados.getModel();
            DefaultListModel<String>  listModelDisponibles = (DefaultListModel<String>)listaGustosDisponibles.getModel();

            listaGustosDisponibles.setEnabled(false);
            listModelSeleccionados.removeAllElements();
            listaGustosSeleccionados.setEnabled(false);
            listModelDisponibles.removeAllElements();
            
             List<String> listaGustos = Arrays.asList("Frutilla", "Vainilla", "Limon", "Chocolate");
            for (String gusto : listaGustos) {
             listModelDisponibles.addElement(gusto);
         }
        }
        
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void RadioCuartoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RadioCuartoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RadioCuartoActionPerformed

    private void listaGustosDisponiblesPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_listaGustosDisponiblesPropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_listaGustosDisponiblesPropertyChange

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jTextField1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox CheckBañadoEnChocolate;
    private javax.swing.JComboBox<String> ComboCantidadDeGustos;
    private javax.swing.JRadioButton RadioCuarto;
    private javax.swing.JRadioButton RadioCucurucho;
    private javax.swing.JRadioButton RadioKilo;
    private javax.swing.JRadioButton RadioMedio;
    private javax.swing.JRadioButton RadioVasito;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JButton jButtonAgregar;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonConfirmar;
    private javax.swing.JButton jButtonImprimir;
    private javax.swing.JButton jButtonQuitar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JList<String> listaGustosDisponibles;
    private javax.swing.JList<String> listaGustosSeleccionados;
    // End of variables declaration//GEN-END:variables
}
