
package main;

import presentacion.VentanaPrincipal;

/**
 *
 * @author FenandoMarina
 */
public class HeladeriaFinalFernandoMarina {

    public static void main(String[] args) {

        
         VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
            
    }
    
}
