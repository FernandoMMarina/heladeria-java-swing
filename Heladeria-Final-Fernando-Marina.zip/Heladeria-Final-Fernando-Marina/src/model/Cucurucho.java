/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author fernandomarina
 */

public class Cucurucho extends TipoDeHelado{
     private boolean baniadoEnChocolate;
        public Cucurucho(float precio, boolean estaBaniadoEnChocolate) {
            super.precioHelado=precio;
            baniadoEnChocolate = estaBaniadoEnChocolate;
        }
    
    @Override
    public String describirHelado(){
        String mensaje =  ".Y el precio es :" + super.precioHelado;
            
        if (baniadoEnChocolate==true){
            mensaje = mensaje + ". Además esta bañado en chocolate. ";
        }else{
            mensaje = mensaje + ". Además NO está bañado en chocolate. "; 
        }
        return mensaje;
        
    }
     @Override
    public String describirPrecio(){
        String mensaje =""+super.precioHelado;
        return mensaje;
    }
    
}
