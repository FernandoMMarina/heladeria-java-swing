
package model;
/**
 *
 * @author fernandomarina
 */
public class Vasito extends TipoDeHelado{
    
        public Vasito( float precio) {
            super.precioHelado=precio;
        }
    /**
     *
     * @return
     */
    @Override
    public String describirHelado(){
       String mensaje = "El precio del Helado es :"+super.precioHelado;
       return mensaje;
                }
        @Override
    public String describirPrecio(){
        String mensaje =""+super.precioHelado;
        return mensaje;
    }
}
