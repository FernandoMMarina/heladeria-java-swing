
package model;

/**
 *
 * @author fernandomarina
 */
public class Cuarto extends TipoDeHelado {
    public Cuarto (float precio){
        super.precioHelado=precio;
    }
    @Override
    public String describirHelado(){
       String mensaje = "El precio del Helado es :"+super.precioHelado;
       return mensaje;
                }
        @Override
    public String describirPrecio(){
        String mensaje =""+super.precioHelado;
        return mensaje;
    }
}
