
package model;

/**
 *
 * @author fernandomarina
 */
import presentacion.VentanaPrincipal;
public abstract class TipoDeHelado {
    
     protected float precioHelado;
    
    public abstract String describirHelado();
    public abstract String describirPrecio();   
    
}
