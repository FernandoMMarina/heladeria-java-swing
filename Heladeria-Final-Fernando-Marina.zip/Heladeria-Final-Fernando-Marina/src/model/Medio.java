
package model;

/**
 *
 * @author fernandomarina
 */
public class Medio extends TipoDeHelado{
    public Medio(float precio){
        super.precioHelado = precio ;
    }
    @Override
    public String describirHelado(){
       String mensaje = "El precio del Helado es :"+super.precioHelado;
       return mensaje;
                }
        @Override
    public String describirPrecio(){
        String mensaje =""+super.precioHelado;
        return mensaje;
    }
}
